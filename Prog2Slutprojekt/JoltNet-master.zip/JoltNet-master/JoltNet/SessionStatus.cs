﻿namespace JoltNet
{
    /// <summary>
    /// The status of a Game Jolt session.
    /// </summary>
    public enum SessionStatus
    {
        Active,
        Idle
    }
}
